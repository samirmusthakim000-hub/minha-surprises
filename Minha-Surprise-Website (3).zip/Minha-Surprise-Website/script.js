/* ==========================================================================
   script.js — all the behaviour of the surprise
   Sections: helpers · calm mode · sparkles · intro · gift · reveals ·
             floating hearts · love words · gallery + lightbox · reasons ·
             envelope letter · music · ending · start-up
   ========================================================================== */
(() => {
  'use strict';

  const C = window.SURPRISE_CONFIG || {};

  /* ---------- Helpers ---------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const later = (fn, ms) => setTimeout(fn, ms);

  // Saves small preferences (like Calm mode). Wrapped in try/catch because
  // some private browser windows block localStorage.
  const store = {
    get(key, fallback) {
      try { const v = localStorage.getItem(key); return v === null ? fallback : v; }
      catch (e) { return fallback; }
    },
    set(key, value) {
      try { localStorage.setItem(key, value); } catch (e) { /* ignore */ }
    }
  };

  /* ---------- Calm mode (fewer animations) ---------- */
  const systemPrefersCalm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  let calm = store.get('minha-calm', systemPrefersCalm ? '1' : '0') === '1';
  const calmBtn = $('#calmToggle');

  function applyCalm() {
    document.body.classList.toggle('calm', calm);
    calmBtn.setAttribute('aria-pressed', String(calm));
    calmBtn.textContent = calm ? '✨ Calm: on' : '✨ Calm mode';
  }

  calmBtn.addEventListener('click', () => {
    calm = !calm;
    store.set('minha-calm', calm ? '1' : '0');
    applyCalm();
    resizeCanvas();
  });

  /* ---------- Glowing sparkles (one canvas for the whole site) ---------- */
  const canvas = $('#sparkles');
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0, dpr = 1, particles = [];
  const GLOW_COLORS = ['255,126,182', '255,77,141', '185,140,255', '247,213,106'];

  function makeParticle() {
    return {
      x: rand(0, W), y: rand(0, H), r: rand(0.8, 2.4),
      vx: rand(-0.08, 0.08), vy: rand(-0.28, -0.05),
      a: rand(0.3, 0.9), tw: rand(0, 6.28), c: pick(GLOW_COLORS)
    };
  }

  function resizeCanvas() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = calm ? 14 : Math.min(60, Math.floor((W * H) / 20000));
    particles = Array.from({ length: count }, makeParticle);
  }

  function drawFrame() {
    ctx.clearRect(0, 0, W, H);
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy; p.tw += 0.02;
      if (p.y < -12) { p.y = H + 12; p.x = rand(0, W); }
      if (p.x < -12) p.x = W + 12;
      if (p.x > W + 12) p.x = -12;
      const alpha = p.a * (0.6 + 0.4 * Math.sin(p.tw));
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4);
      g.addColorStop(0, `rgba(${p.c},${alpha})`);
      g.addColorStop(1, `rgba(${p.c},0)`);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2); ctx.fill();
    }
    requestAnimationFrame(drawFrame);
  }

  /* ---------- Hearts that drift up behind sections ---------- */
  const HEARTS = ['❤', '💗', '💖', '🩷', '💕'];
  const FLOAT_COLORS = { pink: '#ff7eb6', purple: '#b98cff', yellow: '#ffd83a', gold: '#f7d56a' };

  function spawnFloatingHeart(layer, kind) {
    if (calm || layer.childElementCount > 20) return;
    const el = document.createElement('span');
    el.className = 'fheart';
    el.textContent = kind === 'yellow' ? pick(['⚡', '✨', '💛']) : pick(HEARTS);
    el.style.left = rand(0, 96) + '%';
    el.style.setProperty('--fs', rand(12, 28) + 'px');
    el.style.setProperty('--fd', rand(7, 13) + 's');
    el.style.setProperty('--sway', rand(-60, 60) + 'px');
    el.style.setProperty('--fc', FLOAT_COLORS[kind] || FLOAT_COLORS.pink);
    el.addEventListener('animationend', () => el.remove());
    layer.appendChild(el);
  }

  /* ---------- 1. Intro (text one line at a time, then TAP TO BEGIN) ---------- */
  const introEl = $('#intro');
  const introLines = $$('.intro-line');
  const beginBtn = $('#beginBtn');
  const HOLD_MS = calm ? 1800 : 4200;   // each line stays about 4 seconds
  let introIndex = 0, introDone = false, introTimer = null;

  function showIntroLine(i) {
    introLines.forEach((el, k) => {
      el.classList.toggle('on', k === i);
      el.classList.toggle('off', k < i);
    });
  }

  function advanceIntro() {
    if (introDone) return;
    introIndex += 1;
    if (introIndex < introLines.length) {
      showIntroLine(introIndex);
      introTimer = later(advanceIntro, HOLD_MS);
    } else {
      showBeginButton();
    }
  }

  function showBeginButton() {
    if (introDone) return;
    introDone = true;
    clearTimeout(introTimer);
    introLines.forEach((el) => { el.classList.remove('on'); el.classList.add('off'); });
    beginBtn.hidden = false;
  }

  // Tap anywhere on the intro to move on faster
  introEl.addEventListener('click', (e) => {
    if (e.target.closest('button')) return;
    clearTimeout(introTimer);
    advanceIntro();
  });
  $('#skipIntro').addEventListener('click', () => { clearTimeout(introTimer); showBeginButton(); });
  beginBtn.addEventListener('click', startExperience);

  function startExperience() {
    // Music starts here, because this tap counts as the visitor's permission
    playMusic();
    introEl.classList.add('is-leaving');
    $('#gift').classList.add('is-active');
    later(() => introEl.classList.remove('is-active', 'is-leaving'), 1700);
  }

  /* ---------- 2. Gift box + heart explosion ---------- */
  const giftBox = $('#giftBox');
  const giftEl = $('#gift');
  let giftOpened = false;

  giftBox.addEventListener('click', openGift);

  function openGift() {
    if (giftOpened) return;
    giftOpened = true;
    giftBox.classList.add('is-open');
    giftBox.disabled = true;
    heartExplosion();
    later(revealMain, 2100);
  }

  function heartExplosion() {
    const count = calm ? 10 : 46;
    const spread = Math.min(window.innerWidth, 460) * 0.5;
    const colors = ['#ff7eb6', '#ff4d8d', '#e11d48', '#b98cff', '#f7d56a'];
    for (let i = 0; i < count; i++) {
      const el = document.createElement('span');
      el.className = 'burst';
      el.textContent = pick(['❤', '💖', '💗', '✨', '❤']);
      el.style.setProperty('--dx', rand(-spread, spread) + 'px');
      el.style.setProperty('--dy', rand(-spread * 1.3, spread * 0.6) + 'px');
      el.style.setProperty('--r', rand(-200, 200) + 'deg');
      el.style.setProperty('--s', rand(16, 36) + 'px');
      el.style.setProperty('--c', pick(colors));
      el.style.setProperty('--d', rand(0, 0.25) + 's');
      document.body.appendChild(el);
      later(() => el.remove(), 2800);
    }
  }

  /* ---------- 3. Reveal the main surprise ---------- */
  const main = $('#main');
  let mainShown = false;

  function revealMain() {
    if (mainShown) return;
    mainShown = true;
    main.hidden = false;
    $('#miniPlayer').hidden = false;
    window.scrollTo(0, 0);
    giftEl.classList.add('is-leaving');
    later(() => giftEl.classList.remove('is-active', 'is-leaving'), 1700);
    buildGallery();
    setupSectionObservers();
  }

  /* ---------- Section observers: reveal text, start sequences, floating hearts ---------- */
  function setupSectionObservers() {
    // Floating hearts layer for each section that asks for it
    $$('[data-float]').forEach((sec) => {
      const layer = document.createElement('div');
      layer.className = 'float-layer';
      layer.setAttribute('aria-hidden', 'true');
      sec.prepend(layer);
      sec._layer = layer;
      sec._kind = sec.dataset.float;
    });

    const floatTimers = new Map();
    const floatIO = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        const sec = en.target;
        if (en.isIntersecting) {
          if (floatTimers.has(sec)) return;
          for (let i = 0; i < 3; i++) spawnFloatingHeart(sec._layer, sec._kind);
          floatTimers.set(sec, setInterval(() => spawnFloatingHeart(sec._layer, sec._kind), calm ? 3000 : 1100));
        } else if (floatTimers.has(sec)) {
          clearInterval(floatTimers.get(sec));
          floatTimers.delete(sec);
        }
      });
    }, { threshold: 0 });
    $$('[data-float]').forEach((sec) => floatIO.observe(sec));

    // One-time reveals: titles, line-by-line blocks, the ending, and the love words
    const revealIO = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const el = en.target;
        revealIO.unobserve(el);
        if (el.classList.contains('reveal')) el.classList.add('in');
        if (el.matches('[data-seq]')) sequence(el);
        if (el.matches('[data-seq-one]')) later(() => el.classList.add('show'), Number(el.dataset.delay) || 0);
        if (el.id === 'ending') updateEndingButton();
        if (el.id === 'words') startWords();
      });
    }, { threshold: 0.3 });

    $$('.reveal, [data-seq], [data-seq-one], #ending, #words').forEach((el) => revealIO.observe(el));
  }

  /* Shows children one after another. Gap and start time can be set in HTML with data-gap / data-start. */
  function sequence(container) {
    const gap = calm ? 120 : (Number(container.dataset.gap) || 1000);
    const start = calm ? 0 : (Number(container.dataset.start) || 0);
    const items = $$('.line, .nick, .arab-card', container);
    items.forEach((el, i) => {
      later(() => {
        el.classList.add('show');
        if (el.classList.contains('nick') && !calm) later(() => el.classList.add('breathe'), 1600);
      }, start + i * gap);
    });
  }

  /* ---------- 4. Animated love words (one at a time, fading in and out) ---------- */
  const words = $$('#wordStage .word');
  const dotsWrap = $('#wordDots');
  let wordIndex = -1, wordTimer = null, wordsStarted = false;

  words.forEach(() => {
    const d = document.createElement('span');
    d.className = 'dot';
    dotsWrap.appendChild(d);
  });

  function startWords() {
    if (wordsStarted) return;
    wordsStarted = true;
    nextWord();
    wordTimer = setInterval(nextWord, calm ? 2800 : 3800);
  }

  function nextWord() {
    const dots = $$('.dot', dotsWrap);
    if (wordIndex >= 0) {
      words[wordIndex].classList.remove('on');
      words[wordIndex].classList.add('off');
      dots[wordIndex].classList.remove('on');
    }
    wordIndex = (wordIndex + 1) % words.length;
    const cur = words[wordIndex];
    cur.classList.remove('off');
    void cur.offsetWidth; // restart the transition cleanly
    cur.classList.add('on');
    dots[wordIndex].classList.add('on');
  }

  /* ---------- 5. Photo gallery + full-screen viewer ---------- */
  const tabsEl = $('#galleryTabs');
  const gridEl = $('#galleryGrid');
  const lb = $('#lightbox');
  const lbImg = $('#lbImg');
  const lbCaption = $('#lbCaption');
  const lbCount = $('#lbCount');
  let lbList = [], lbIndex = 0, lbOpen = false, touchStartX = null;

  // Only categories that have photos are shown
  function buildGallery() {
    const cats = (C.categories || []).filter((c) => c.photos && c.photos.length);
    tabsEl.innerHTML = '';
    if (!cats.length) { $('#gallery').hidden = true; return; }
    cats.forEach((cat, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tab';
      b.setAttribute('role', 'tab');
      b.textContent = cat.title;
      b.addEventListener('click', () => showCategory(cat));
      tabsEl.appendChild(b);
      if (i === 0) showCategory(cat);
    });
  }

  function showCategory(cat) {
    $$('.tab', tabsEl).forEach((t) => t.setAttribute('aria-selected', String(t.textContent === cat.title)));
    gridEl.innerHTML = '';
    cat.photos.forEach((p, i) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'photo';
      card.setAttribute('aria-label', 'Open photo: ' + (p.caption || cat.title));
      const img = document.createElement('img');
      img.src = p.src;
      img.alt = p.caption || cat.title;
      img.loading = 'lazy';
      img.decoding = 'async';
      img.onerror = () => { card.hidden = true; };   // hide a photo whose file is missing
      const cap = document.createElement('span');
      cap.className = 'cap';
      cap.textContent = p.caption || '';
      card.append(img, cap);
      card.addEventListener('click', () => openLightbox(cat.photos, i));
      gridEl.appendChild(card);
    });
    // One-by-one reveal
    $$('.photo', gridEl).forEach((el, i) => later(() => el.classList.add('in'), 80 + i * (calm ? 30 : 120)));
  }

  function openLightbox(list, index) {
    lbList = list;
    lbOpen = true;
    lb.hidden = false;
    document.body.style.overflow = 'hidden';
    showLightboxPhoto(index);
  }

  function closeLightbox() {
    lbOpen = false;
    lb.hidden = true;
    document.body.style.overflow = '';
  }

  function showLightboxPhoto(index) {
    const len = lbList.length;
    lbIndex = (index + len) % len;
    const p = lbList[lbIndex];
    lbImg.classList.add('swap');
    later(() => {
      lbImg.src = p.src;
      lbImg.alt = p.caption || '';
      lbCaption.textContent = p.caption || '';
      lbCount.textContent = `${lbIndex + 1} / ${len}`;
      lbImg.classList.remove('swap');
    }, 220);
    // Preload the next photo so the swipe feels smooth
    const next = lbList[(lbIndex + 1) % len];
    if (next) { const pre = new Image(); pre.src = next.src; }
  }

  $('#lbClose').addEventListener('click', closeLightbox);
  $('#lbPrev').addEventListener('click', (e) => { e.stopPropagation(); showLightboxPhoto(lbIndex - 1); });
  $('#lbNext').addEventListener('click', (e) => { e.stopPropagation(); showLightboxPhoto(lbIndex + 1); });
  lb.addEventListener('click', (e) => { if (e.target === lb) closeLightbox(); });

  document.addEventListener('keydown', (e) => {
    if (!lbOpen) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') showLightboxPhoto(lbIndex - 1);
    if (e.key === 'ArrowRight') showLightboxPhoto(lbIndex + 1);
  });

  // Swipe left or right on phones
  lb.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', (e) => {
    if (touchStartX === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX;
    touchStartX = null;
    if (Math.abs(dx) > 45) showLightboxPhoto(dx < 0 ? lbIndex + 1 : lbIndex - 1);
  });

  /* ---------- 6. Why You Are Special (15 messages, one by one) ---------- */
  const reasons = C.reasons || [];
  const reasonsBtn = $('#reasonsBtn');
  const reasonCard = $('#reasonCard');
  const reasonText = $('#reasonText');
  const reasonCount = $('#reasonCount');
  let reasonIndex = -1, reasonTimer = null;

  reasonsBtn.addEventListener('click', () => {
    reasonCard.hidden = false;
    reasonsBtn.textContent = 'NEXT REASON ❤️';
    showReason(reasonIndex + 1 >= reasons.length ? 0 : reasonIndex + 1);
    reasonsBtn.blur();
  });
  reasonCard.addEventListener('click', () => showReason(reasonIndex + 1));

  function showReason(i) {
    if (!reasons.length) return;
    clearTimeout(reasonTimer);
    if (i >= reasons.length) {
      reasonIndex = reasons.length - 1;
      reasonCount.textContent = `${reasons.length} / ${reasons.length}`;
      reasonText.textContent = 'And that is only the beginning, My Pikachu. ❤️';
      reasonsBtn.textContent = 'READ THEM AGAIN ❤️';
      return;
    }
    reasonIndex = i;
    reasonCount.textContent = `${i + 1} / ${reasons.length}`;
    reasonText.style.animation = 'none';
    void reasonText.offsetWidth;
    reasonText.style.animation = '';
    reasonText.textContent = reasons[i];
    // Move on by itself after a few seconds, unless the visitor taps first
    reasonTimer = later(() => showReason(i + 1), calm ? 6000 : 5200);
  }

  /* ---------- 7. Envelope love letter ---------- */
  const envelope = $('#envelope');
  const letterPaper = $('#letterPaper');
  let letterOpened = false;

  envelope.addEventListener('click', () => {
    if (letterOpened) return;
    letterOpened = true;
    envelope.classList.add('is-open');
    envelope.setAttribute('aria-expanded', 'true');
    envelope.disabled = true;
    later(() => letterPaper.classList.add('is-up'), 900);      // letter rises out
    const lines = $$('.letter-inner .line', letterPaper);
    const gap = calm ? 150 : 1100;
    lines.forEach((el, i) => later(() => el.classList.add('show'), 1900 + i * gap)); // line by line
  });

  /* ---------- 8. Background music ---------- */
  const song = $('#song');
  const volumeInputs = $$('[data-volume]');
  const musicToggles = $$('[data-music-toggle]');
  const musicStatuses = $$('[data-music-status]');
  const vinyl = $('[data-music-spin]');
  const endingPlay = $('#playEndingSong');
  const endingSection = $('#ending');
  let level = Number(C.music && C.music.defaultVolume) || 0.25;   // low by default
  let musicState = 'ready';
  let fadeFrame = null;

  if (C.music && C.music.src) song.src = C.music.src;
  song.volume = level;
  volumeInputs.forEach((input) => { input.value = String(level); });

  function setMusicState(state) {
    musicState = state;
    const text = {
      ready: 'Tap play to listen',
      playing: 'Now playing ♪ ' + (C.music && C.music.title ? C.music.title : ''),
      paused: 'Paused. Tap play to continue',
      ended: 'Our song has finished ❤️',
      error: 'Tap play to start the music'
    }[state];
    musicStatuses.forEach((el) => { el.textContent = text; });
    musicToggles.forEach((btn) => {
      if (btn === endingPlay) return;
      btn.textContent = state === 'playing' ? '❚❚' : '▶';
      btn.setAttribute('aria-label', state === 'playing' ? 'Pause music' : 'Play music');
    });
    vinyl.classList.toggle('playing', state === 'playing');
    updateEndingButton();
  }

  // Smoothly moves the volume to a target level
  function fadeVolume(target, ms, done) {
    cancelAnimationFrame(fadeFrame);
    const from = song.volume;
    const t0 = performance.now();
    const step = (now) => {
      const k = Math.min(1, (now - t0) / ms);
      song.volume = Math.max(0, Math.min(1, from + (target - from) * k));
      if (k < 1) fadeFrame = requestAnimationFrame(step);
      else if (done) done();
    };
    fadeFrame = requestAnimationFrame(step);
  }

  function playMusic() {
    if (!C.music || !C.music.src) return;
    song.volume = 0;
    const p = song.play();
    if (p && p.then) {
      p.then(() => {
        setMusicState('playing');
        fadeVolume(level, 3000);   // gentle fade-in
      }).catch(() => setMusicState('error'));
    }
  }

  function pauseMusic() {
    song.pause();
    setMusicState('paused');
  }

  function toggleMusic() {
    if (song.paused) playMusic();
    else pauseMusic();
  }

  musicToggles.forEach((btn) => btn.addEventListener('click', toggleMusic));
  volumeInputs.forEach((input) => {
    input.addEventListener('input', () => {
      level = Number(input.value);
      volumeInputs.forEach((other) => { other.value = input.value; });
      if (!fadeFrame || musicState === 'playing') song.volume = level;
    });
  });
  song.addEventListener('ended', () => setMusicState('ended'));
  song.addEventListener('error', () => setMusicState('error'));

  // In the ending, the song's play button appears if the music is paused
  function updateEndingButton() {
    if (!endingPlay || !endingSection) return;
    const show = musicState !== 'playing' && mainShown && endingSection.getBoundingClientRect().top < window.innerHeight * 0.6;
    endingPlay.hidden = !show;
  }

  /* ---------- 9. Final surprise + Replay ---------- */
  $('#replayBtn').addEventListener('click', () => {
    // Fade the song out gently, then start the whole surprise again
    fadeVolume(0, 1200, () => { song.pause(); window.location.reload(); });
  });

  // Keep the ending button up to date while scrolling
  window.addEventListener('scroll', () => { if (mainShown) updateEndingButton(); }, { passive: true });

  /* ---------- Start-up ---------- */
  applyCalm();
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  requestAnimationFrame(drawFrame);

  introLines.forEach((el) => el.classList.remove('on', 'off'));
  showIntroLine(0);
  introTimer = later(advanceIntro, HOLD_MS);
  setMusicState('ready');
})();
