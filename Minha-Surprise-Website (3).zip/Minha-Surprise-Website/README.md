# For My Pikachu ❤️ — Minha's Surprise Website

Created with love by **MUSTHAKIM**.

This is a password-protected romantic website. Minha opens the link, types the secret word, and the surprise begins.

---

## 1. What is in the folder?

| File / folder | What it does (in simple words) |
|---|---|
| `index.html` | The main page: every section of the surprise |
| `style.css` | Colours, animations and layout. The colour settings are at the top |
| `script.js` | Makes everything move and respond when tapped |
| `config.js` | **The file you edit most.** Photos, captions, music name and the 15 reasons |
| `locked.html` | The password (lock) screen |
| `functions/_middleware.js` | The security guard. It runs on Cloudflare's servers and blocks everything until the password is right |
| `functions/api/unlock.js` | Checks the typed password on the server |
| `_headers` | Small settings that tell browsers not to index the site |
| `assets/photos/` | Photos (sorted into folders) |
| `assets/pikachu/` | The Pikachu picture (`pikachu.svg`) and any extra Pikachu photos |
| `assets/music/` | The song file |

---

## 2. Adding or changing photos

1. Put the photo in the matching folder:
   - `assets/photos/minha/` → Minha's Beautiful Pictures
   - `assets/photos/childhood/` → Minha's Childhood Memories
   - `assets/photos/selfies/` → Mirror Selfies
   - `assets/photos/memories/` → Our Special Memories
   - `assets/pikachu/` → Pikachu Memories
2. Open `config.js` and add a line for it in the right category, for example:
   ```js
   { src: 'assets/photos/minha/minha-09.jpg', caption: 'Simply beautiful' },
   ```
3. Keep photos about **1200 pixels or less** on the long side and under **300 KB** each so the site loads fast.
4. A category with no photos is hidden automatically, so it appears once you add a photo to it.
5. Aim for 20–40 photos in total. You currently have 15.

---

## 3. Adding or changing the music

1. Only use music you have permission to use. Copy your file into `assets/music/`.
2. Open `config.js` and change the `music` section:
   ```js
   music: {
     src: 'assets/music/arz-kiya-hai.mp3',   // your file name
     title: 'Arz Kiya Hai',
     artist: 'Anuv Jain',
     defaultVolume: 0.25                      // 0 = silent, 1 = loud
   },
   ```
3. The song starts only after Minha taps **TAP TO BEGIN**, because phones block music until someone taps. It starts quietly. There is also a volume slider and a play/pause button.

---

## 4. Testing on your PC (Windows)

You only need this to try the site before publishing.

1. Install **Node.js** (LTS version) from https://nodejs.org, then restart your computer.
2. Open the project folder, click the address bar, type `cmd` and press Enter.
3. Create a file named `.dev.vars` in the project folder (use Notepad, "Save as type: All files"). Put one line in it:
   ```
   SITE_PASSWORD=your-secret-word-here
   ```
   This file is only for your PC. It is hidden from visitors and must not be shared.
4. In the black window, type this and press Enter:
   ```
   npx wrangler pages dev .
   ```
5. Open the link it shows (usually `http://localhost:8788`) in Chrome. You should see the lock screen. Type your secret word.

**Check list on PC:** lock screen appears · wrong word shows a friendly message · right word opens the intro · TAP TO BEGIN starts the music · the gift opens with hearts · the gallery arrows and swipe work · the envelope opens · Replay returns to the start.

---

## 5. Publishing on Cloudflare Pages (step by step)

1. Create a free account at https://dash.cloudflare.com (sign up with email).
2. In the left menu, click **Workers & Pages**, then **Create**, then the **Pages** tab.
3. Choose **Upload assets** (drag-and-drop, no coding needed). Give the project a name such as `minha-surprise`, then click **Create project**.
4. Drag the **whole** `Minha-Surprise-Website` folder into the box (or drag the files and folders inside it). Make sure `functions` and `assets` are included.
5. Click **Deploy site**. You get a link like `https://minha-surprise.pages.dev`.
6. **Set the password now (see section 6), then redeploy** so the password takes effect.

Later changes: go to your project, click **Create new deployment** (or **Upload assets** again) and upload the updated folder.

---

## 6. Setting the password securely

The password is **never** written in the website files. It is stored as a secret inside Cloudflare.

1. In Cloudflare, open **Workers & Pages** → your project (`minha-surprise`).
2. Click **Settings** → **Variables and Secrets** (or **Environment variables**).
3. Click **Add**:
   - **Variable name:** `SITE_PASSWORD`
   - **Value:** your secret word (choose something only you two would know, and at least 8 characters with a mix of letters and numbers)
   - **Type:** choose **Secret** (this hides the value after saving)
4. Click **Save**.
5. Optional but recommended: add a second secret named `SESSION_SECRET` with a long random text (30+ random characters). It signs the login cookie. If you skip it, the site uses `SITE_PASSWORD` instead.
6. Go to **Deployments** and redeploy the latest version so the new settings apply.

**To change the password later:** edit the `SITE_PASSWORD` secret, then redeploy. Everyone will need to log in again, which is good if the old word was shared.

**Never** put the password in `config.js`, `index.html`, `locked.html`, or any other file.

---

## 7. Testing the password on a mobile phone

1. On your phone, open the link (`https://minha-surprise.pages.dev`) in Chrome (Android) or Safari (iPhone).
2. You should see the **lock screen**, not the photos. The photo and music links are blocked too.
3. Type a **wrong** word. A friendly message should appear.
4. Type the **correct** word and tap **Unlock My Surprise**. The intro should appear.
5. Close the browser completely, open the link again. The site should remember you for 7 days.
6. Try opening `https://minha-surprise.pages.dev/assets/music/arz-kiya-hai.mp3` directly in a new tab. It should say **"This surprise is locked."**
7. Turn on **Calm mode** (top-right button) to test the reduced-motion option.

---

## 8. Troubleshooting

- **Lock screen says "not ready yet":** the `SITE_PASSWORD` secret is missing. Add it (section 6) and redeploy.
- **Correct word is rejected:** check for typing mistakes and capital letters, and that you redeployed after setting the secret.
- **Music does not start on iPhone:** tap the ▶ button once. Phones only allow sound after a tap, and the Begin button counts.
- **A photo is missing:** check the file name in `config.js` matches the file exactly (capital letters and `.jpg` vs `.jpeg` matter). Missing photos are hidden automatically.
- **Slow on an old phone:** open the page, tap **Calm mode** (top-right), and use smaller photos.

---

*Made with love for Minha ❤️ by MUSTHAKIM.*
