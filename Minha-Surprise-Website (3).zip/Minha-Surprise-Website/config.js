/* ==========================================================================
   config.js — EASY EDITING FILE
   Change names, photos, captions, music and the 15 reasons here.
   Save the file, then refresh the website.
   ========================================================================== */

window.SURPRISE_CONFIG = {

  /* Names used across the site */
  recipient: 'Minha',
  creator: 'MUSTHAKIM',

  /* MUSIC — put your permitted audio file in assets/music/ and change the path below */
  music: {
    src: 'assets/music/arz-kiya-hai.mp3',
    title: 'Arz Kiya Hai',
    artist: 'Anuv Jain',
    defaultVolume: 0.25          // 0.0 (silent) to 1.0 (loud). 0.25 = soft by default
  },

  /* PHOTO GALLERY — each category shows only if it has photos.
     To add a photo: copy it into the matching folder, then add a line like the ones below.
     Keep the captions gentle; never claim dates or events you do not want to be wrong about. */
  categories: [
    {
      id: 'beautiful',
      title: "Minha's Beautiful Pictures",
      photos: [
        { src: 'assets/photos/minha/minha-01.jpg', caption: 'Simply beautiful' },
        { src: 'assets/photos/minha/minha-02.jpg', caption: 'Elegance in every frame' },
        { src: 'assets/photos/minha/minha-03.jpg', caption: 'Soft, graceful, perfect' },
        { src: 'assets/photos/minha/minha-04.jpg', caption: 'A look that stays with me' },
        { src: 'assets/photos/minha/minha-05.jpg', caption: 'Calm, bright, and yours' },
        { src: 'assets/photos/minha/minha-06.jpg', caption: 'Glowing in golden light' },
        { src: 'assets/photos/minha/minha-07.jpg', caption: 'My favourite view' },
        { src: 'assets/photos/minha/minha-08.jpg', caption: 'Pure elegance' }
      ]
    },
    {
      id: 'childhood',
      title: "Minha's Childhood Memories",
      photos: [
        { src: 'assets/photos/childhood/childhood-01.jpg', caption: 'Tiny and already adorable' },
        { src: 'assets/photos/childhood/childhood-02.jpg', caption: 'A little star in the making' },
        { src: 'assets/photos/childhood/childhood-03.jpg', caption: 'Cute, curious, and sweet' }
      ]
    },
    {
      id: 'selfies',
      title: 'Mirror Selfies',
      // Empty for now: this category stays hidden until you add photos here.
      // Example: { src: 'assets/photos/selfies/selfie-01.jpg', caption: 'Mirror, mirror' }
      photos: []
    },
    {
      id: 'memories',
      title: 'Our Special Memories',
      photos: [
        { src: 'assets/photos/memories/memories-01.jpg', caption: 'Us, together' },
        { src: 'assets/photos/memories/memories-02.jpg', caption: 'Hand in hand' },
        { src: 'assets/photos/memories/memories-03.jpg', caption: 'My favourite place is next to you' },
        { src: 'assets/photos/memories/memories-04.jpg', caption: 'Just us, and that is enough' }
      ]
    },
    {
      id: 'pikachu',
      title: 'Pikachu Memories',
      // Empty for now: add photos to assets/pikachu/ and list them here.
      photos: []
    }
  ],

  /* WHY YOU ARE SPECIAL — 15 messages, shown one by one */
  reasons: [
    'Your smile is the quiet light that turns ordinary days into something I want to remember.',
    'Even a plain, ordinary day feels like a small celebration when you are in it.',
    'Your happiness is something I check on quietly, all day, without needing any reason.',
    'You have a way of making a loud world sound a little softer.',
    'Nobody laughs at the world quite the way you do, and I would not trade that for anything.',
    'You are the kind of person people feel lucky to know. I feel luckiest of all.',
    'Your little sulks and your sweet words both feel like home to me.',
    'You make small kindnesses look effortless, the way sunlight makes a room look warm.',
    'Every dream you chase deserves a whole cheering section, and I am the loudest one in it.',
    'You are one of a kind. That is not an exaggeration, just a fact I notice every day.',
    'When you are near, my worries learn to sit down and wait outside.',
    'Your heart is gentle in a way that makes the whole world feel a little safer.',
    'You make me want to become a better version of myself, every single day.',
    'Some people are a place you visit. You are the place I keep coming back to.',
    'And the reason behind all the others: you are simply you, and that is more than enough.'
  ]
};
