/* ==========================================================================
   functions/_middleware.js — the password gate (runs on the SERVER)
   ----------------------------------------------------------------------
   Cloudflare runs this file before every request to the website. It:
     - lets the visitor reach only the lock screen until the password is right
     - blocks direct links to photos and music until then
     - hides any file whose name starts with a dot (such as .dev.vars)
   The password itself is never in this file. It is read from the
   Cloudflare secret called SITE_PASSWORD (see README.md).
   ========================================================================== */

const SESSION_COOKIE = 'minha_session';
const SESSION_DAYS = 7;

// Pages that anyone may open without the password
const PUBLIC_PATHS = new Set(['/locked', '/locked.html', '/api/unlock', '/favicon.ico']);

const encoder = new TextEncoder();

/* Turns bytes into a web-safe text string (used in the cookie) */
function toBase64Url(bytes) {
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/* Creates the key used to sign the session cookie.
   Uses SESSION_SECRET if you set it, otherwise SITE_PASSWORD. */
async function getSigningKey(env) {
  const secret = env.SESSION_SECRET || env.SITE_PASSWORD;
  if (!secret) return null;
  return crypto.subtle.importKey(
    'raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']
  );
}

/* Checks that a cookie token is genuine and not expired */
async function isValidSession(request, env) {
  const cookie = request.headers.get('Cookie') || '';
  const match = cookie.match(new RegExp('(?:^|;\\s*)' + SESSION_COOKIE + '=([^;]+)'));
  if (!match) return false;

  const token = decodeURIComponent(match[1]);
  const dot = token.indexOf('.');
  if (dot < 1) return false;

  const expires = token.slice(0, dot);
  if (!/^\d+$/.test(expires) || Number(expires) < Date.now()) return false;

  const key = await getSigningKey(env);
  if (!key) return false;

  // Convert the signature back from base64url and check it
  const b64 = token.slice(dot + 1).replace(/-/g, '+').replace(/_/g, '/');
  const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
  let sigBytes;
  try {
    sigBytes = Uint8Array.from(atob(padded), (c) => c.charCodeAt(0));
  } catch (e) {
    return false;
  }
  return crypto.subtle.verify('HMAC', key, sigBytes, encoder.encode(expires));
}

/* The main gate. Cloudflare calls this for every request. */
export async function onRequest(context) {
  const { request, env, next } = context;
  const url = new URL(request.url);
  const path = url.pathname;

  // 1. Hide files and folders whose names start with a dot (such as .dev.vars)
  if (path.split('/').some((part) => part.startsWith('.') && part !== '.well-known')) {
    return new Response('Not found', { status: 404 });
  }

  // 2. Pages anyone can open (the lock screen and its unlock request)
  if (PUBLIC_PATHS.has(path)) return next();

  // 3. Everyone else needs a valid session
  if (await isValidSession(request, env)) return next();

  // 4. Photos and music are blocked completely until unlocked
  if (path.startsWith('/assets/')) {
    return new Response('This surprise is locked.', { status: 403, headers: { 'Cache-Control': 'no-store' } });
  }

  // 5. Everything else goes to the lock screen
  return Response.redirect(new URL('/locked', url).toString(), 302);
}
