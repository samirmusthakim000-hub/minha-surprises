/* ==========================================================================
   functions/api/unlock.js — checks the password and gives a session cookie
   Called by locked.html when Minha presses "Unlock My Surprise".
   The password is compared against the Cloudflare secret SITE_PASSWORD.
   ========================================================================== */

const SESSION_COOKIE = 'minha_session';
const SESSION_DAYS = 7;
const encoder = new TextEncoder();

/* Small helper that sends JSON back to the browser */
function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...extraHeaders }
  });
}

/* Hashes text with SHA-256 so two passwords can be compared safely */
async function sha256(text) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(text)));
}

/* Compares two byte arrays in a fixed amount of time (prevents timing tricks) */
function sameBytes(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

/* Converts bytes to web-safe text for the cookie */
function toBase64Url(bytes) {
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/* POST /api/unlock  with JSON body { "password": "..." } */
export async function onRequestPost(context) {
  const { request, env } = context;

  // If the secret was never set, nobody gets in
  const realPassword = (env.SITE_PASSWORD || '').trim();
  if (!realPassword) {
    return json({ error: 'The surprise is not ready yet. Please ask MUSTHAKIM to set the password.' }, 500);
  }

  let typed = '';
  try {
    const body = await request.json();
    typed = String(body.password || '').trim();
  } catch (e) {
    return json({ error: 'Something went wrong. Please try again.' }, 400);
  }

  // Small pause makes guessing many passwords slow
  await new Promise((resolve) => setTimeout(resolve, 700));

  const matches = sameBytes(await sha256(typed), await sha256(realPassword));
  if (!matches) {
    return json({ error: "Hmm, that's not the secret word. Try again, Pikachu ⚡" }, 401);
  }

  // Create a signed cookie that proves the password was entered
  const signingSecret = env.SESSION_SECRET || realPassword;
  const key = await crypto.subtle.importKey(
    'raw', encoder.encode(signingSecret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const expires = String(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(expires)));
  const token = expires + '.' + toBase64Url(signature);

  // HttpOnly: JavaScript cannot read it. Secure: sent only over HTTPS.
  // SameSite=Strict: other websites cannot use it.
  const cookie = `${SESSION_COOKIE}=${token}; Path=/; Max-Age=${SESSION_DAYS * 24 * 60 * 60}; HttpOnly; Secure; SameSite=Strict`;
  return json({ ok: true }, 200, { 'Set-Cookie': cookie });
}
